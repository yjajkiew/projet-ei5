﻿using System;
using System.Net;
using Newtonsoft.Json;

class Fault04 {
  static void Main() {
    // création d'un WebClient
    WebClient webClient = new WebClient();
    // on précise qu'on va envoyer du Json
    webClient.Headers.Add("Content-Type", "application/json");
    // la valeur postée : un tableau de commandes Json incorrectes
    string commands = JsonConvert.SerializeObject(new[] { new { id = "1", ac = "cl", pa = new { pin = "8", nb = "10" } } });
    Console.WriteLine(string.Format("--> {0}", commands));
    // l'URL 
    string uriString = "http://localhost:8080/rest/arduinos/commands/192.168.2.3/";
    // on envoie la requête et on lit la réponse
    string réponse = webClient.UploadString(uriString, commands);
    Console.WriteLine(string.Format("<-- {0}", réponse));
  }
}
