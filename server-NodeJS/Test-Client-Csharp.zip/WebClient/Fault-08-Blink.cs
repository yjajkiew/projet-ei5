﻿using System;
using System.Net;

class Fault08 {
  static void Main() {
    // création d'un WebClient
    WebClient webClient = new WebClient();
    // on précise qu'on va envoyer du Json
    webClient.Headers.Add("Content-Type", "application/json");
    // l'URL 
    string uriString = "http://localhost:8080/rest/arduinos/blink/1/192.168.2.3/x/10/100/";
    // on envoie la requête et on lit la réponse
    string réponse = webClient.DownloadString(uriString);
    Console.WriteLine(string.Format("<-- {0}", réponse));
  }
}
