﻿using System;
using System.Net;

class Fault13 {
  static void Main() {
    // création d'un WebClient
    WebClient webClient = new WebClient();
    // on précise qu'on va envoyer du Json
    webClient.Headers.Add("Content-Type", "application/json");
    // l'URL 
    string uriString = "http://localhost:8080/rest/arduinos/pinWrite/1/192.168.2.4/8/b/1/";
    // on envoie la requête et on lit la réponse
    string réponse = webClient.DownloadString(uriString);
    Console.WriteLine(string.Format("<-- {0}", réponse));
  }
}
